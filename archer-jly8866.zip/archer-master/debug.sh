#!/bin/bash

python3 manage.py runserver 0.0.0.0:9123  --insecure
